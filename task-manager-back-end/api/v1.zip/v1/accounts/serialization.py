from rest_framework import serializers
from users import models
from django.db.models import Max, Prefetch, Q, Sum



