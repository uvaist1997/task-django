from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404



def get_accounts(id):
    AccountID = "User Not Found"
    return AccountID
